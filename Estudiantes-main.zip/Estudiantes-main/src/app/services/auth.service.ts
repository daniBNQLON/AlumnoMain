import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    GetUserByUsername(username: any) {
      throw new Error('Method not implemented.');
    }
    private usersUrl = '../almacen/usuario.json';

    constructor(private http: HttpClient) {}

    getUsers(): Observable<any[]> {
        return this.http.get<any[]>(this.usersUrl);
    }
}