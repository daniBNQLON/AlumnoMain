import { Component } from '@angular/core';
import { UsuarioService } from '../usuario.service';
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {

  username: string = '';
  password: string = '';

  usuarios: any[] = [];

  constructor(private usuarioService: UsuarioService, private router: Router) { }

  ngOnInit() {
    // Cargar los usuarios desde el archivo JSON
    this.usuarioService.getUsuarios().subscribe(data => {
      this.usuarios = data;
    });
  }

  login() {
    // Buscar si el username y password son correctos
    const usuarioValido = this.usuarios.find(user => user.username === this.username && user.password === this.password);

    if (usuarioValido) {
      console.log('Login exitoso');
      // Redirigir a la página de inicio
      this.router.navigate(['/inicio']);
    } else {
      console.log('Credenciales incorrectas');
      'los datos ingresados no son correctos Intente denuevo'
    }
  }
}
